chrome.app.window.create('window.html', {
    'outerBounds': {
      'width': 400,
      'height': 400
    }
});
