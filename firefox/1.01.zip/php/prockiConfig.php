<?php

$servername = "<host>";
$username = "<user name>";
$password = "<pass>";
$dbname = "<db name>";

?>
