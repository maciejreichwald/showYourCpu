var htmlLink = "http://weddingshots.pl/public_html/procek.php";
